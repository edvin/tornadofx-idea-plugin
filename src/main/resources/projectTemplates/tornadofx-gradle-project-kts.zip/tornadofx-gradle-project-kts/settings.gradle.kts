rootProject.name = "tornadofx-gradle-project-kts"

