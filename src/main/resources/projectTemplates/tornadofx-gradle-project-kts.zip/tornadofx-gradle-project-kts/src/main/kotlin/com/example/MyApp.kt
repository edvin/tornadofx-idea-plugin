package com.example

import com.example.view.MainView
import tornadofx.App

class MyApp: App(MainView::class, Styles::class)