package com.example

import tornadofx.launch

fun main() {
    launch<MyApp>()
}