package com.example.osgidemo.app

import tornadofx.App
import com.example.osgidemo.view.DashboardView

class DashboardApp : App(DashboardView::class, Styles::class)