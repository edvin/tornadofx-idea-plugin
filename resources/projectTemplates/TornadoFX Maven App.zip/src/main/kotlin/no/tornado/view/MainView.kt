package no.tornado.view

import javafx.scene.layout.HBox
import no.tornado.app.Styles.Companion.heading
import tornadofx.View
import tornadofx.addClass
import tornadofx.label

class MainView : View() {
    override val root = HBox()

    init {
        title = "Hello TornadoFX Application"

        with (root) {
            label(title) {
                addClass(heading)
            }
        }
    }
}