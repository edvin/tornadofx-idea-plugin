package ${IJ_BASE_PACKAGE}.view

import ${IJ_BASE_PACKAGE}.app.Styles
import tornadofx.*

class MainView : View("Hello TornadoFX") {
    override val root = hbox {
        label(title) {
            addClass(Styles.heading)
        }
    }
}