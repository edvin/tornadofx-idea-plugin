package ${IJ_BASE_PACKAGE}.view

import ${IJ_BASE_PACKAGE}.app.Styles.Companion.heading
import tornadofx.View
import tornadofx.addClass
import tornadofx.hbox
import tornadofx.label

class MainView : View("Hello TornadoFX Application") {
    override val root = hbox {
        label(title) {
            addClass(heading)
        }
    }
}