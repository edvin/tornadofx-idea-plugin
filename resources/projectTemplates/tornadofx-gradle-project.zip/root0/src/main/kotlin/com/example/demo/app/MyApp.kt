package ${IJ_BASE_PACKAGE}.app

import ${IJ_BASE_PACKAGE}.view.MainView
import tornadofx.App

class MyApp: App(MainView::class, Styles::class)