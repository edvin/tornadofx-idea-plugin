package ${IJ_BASE_PACKAGE}.view

import ${IJ_BASE_PACKAGE}.app.Styles
import tornadofx.*
import tornadofx.osgi.addViewsWhen

class DashboardView : View("Hello TornadoFX OSGi Application") {
    override val root = vbox {
        label(title) {
            addClass(Styles.heading)
        }
        addViewsWhen { it.discriminator == "dashboard" }
    }
}