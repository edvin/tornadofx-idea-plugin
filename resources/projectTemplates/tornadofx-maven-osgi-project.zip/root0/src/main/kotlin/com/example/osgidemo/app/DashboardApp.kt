package ${IJ_BASE_PACKAGE}.app

import tornadofx.App
import ${IJ_BASE_PACKAGE}.view.DashboardView

class DashboardApp : App(DashboardView::class, Styles::class)